package com.google.common.base;

abstract interface package-info
{
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.google.common.base.package-info
 * JD-Core Version:    0.6.2
 */