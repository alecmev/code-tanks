package com.google.common.cache;

abstract interface package-info
{
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.google.common.cache.package-info
 * JD-Core Version:    0.6.2
 */