package com.google.common.net;

abstract interface package-info
{
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.google.common.net.package-info
 * JD-Core Version:    0.6.2
 */