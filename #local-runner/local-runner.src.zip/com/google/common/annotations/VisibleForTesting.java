package com.google.common.annotations;

import java.lang.annotation.Annotation;

@GwtCompatible
public @interface VisibleForTesting
{
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.google.common.annotations.VisibleForTesting
 * JD-Core Version:    0.6.2
 */