package com.a.c.a.a;

import org.apache.log4j.Logger;

public class d
{
  private static final Logger a = Logger.getLogger(d.class);

  private d()
  {
    throw new UnsupportedOperationException();
  }

  public static void a(long paramLong)
  {
    try
    {
      Thread.sleep(paramLong);
    }
    catch (InterruptedException localInterruptedException)
    {
    }
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.c.a.a.d
 * JD-Core Version:    0.6.2
 */