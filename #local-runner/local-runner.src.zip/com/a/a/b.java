package com.a.a;

import java.util.List;
import java.util.Map;

public abstract interface b
{
  public abstract void a(Map paramMap, List paramList);

  public abstract void a();

  public abstract void b();
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.b
 * JD-Core Version:    0.6.2
 */