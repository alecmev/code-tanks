package com.a.a;

import java.util.List;

public abstract interface g
{
  public abstract d a(d paramd);

  public abstract void b(d paramd);

  public abstract List a();

  public abstract com.a.a.a.a.b.e.a a(com.a.a.a.a.b.e.a parama);

  public abstract List b();

  public abstract void c();

  public abstract void a(Class paramClass1, Class paramClass2, a parama);

  public abstract int d();
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.g
 * JD-Core Version:    0.6.2
 */