package com.a.a;

public abstract interface f
{
  public abstract void a(g paramg, int paramInt);
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.f
 * JD-Core Version:    0.6.2
 */