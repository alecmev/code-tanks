package com.a.a.a.a.c.a;

public class d extends RuntimeException
{
  public d(String paramString)
  {
    super(paramString);
  }

  public d(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.c.a.d
 * JD-Core Version:    0.6.2
 */