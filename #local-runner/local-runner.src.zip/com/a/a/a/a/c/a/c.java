package com.a.a.a.a.c.a;

import com.a.a.a.a.c.a.a.e;
import com.a.a.a.a.c.a.a.f;
import java.util.Map;
import java.util.concurrent.TimeUnit;

class c
  implements Runnable
{
  c(a parama)
  {
  }

  public void run()
  {
    if (a.a(this.a) != null)
      if (Boolean.parseBoolean((String)a.b(this.a).get("debug")))
        a.a(this.a).a(TimeUnit.MINUTES.toMillis(10L));
      else
        a.a(this.a).a(TimeUnit.SECONDS.toMillis(5L));
    if (a.c(this.a) != null)
      a.c(this.a).f();
    if (a.a(this.a) != null)
      a.a(this.a).a();
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.c.a.c
 * JD-Core Version:    0.6.2
 */