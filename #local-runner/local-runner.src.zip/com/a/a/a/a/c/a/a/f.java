package com.a.a.a.a.c.a.a;

import com.a.a.a.a.a.b;
import com.a.a.a.a.a.h;
import com.a.a.a.a.a.m;

public abstract interface f
{
  public abstract void a(int paramInt);

  public abstract void a();

  public abstract String b();

  public abstract void b(int paramInt);

  public abstract b[] c();

  public abstract void a(h paramh);

  public abstract m[] d();

  public abstract void e();

  public abstract void f();
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.c.a.a.f
 * JD-Core Version:    0.6.2
 */