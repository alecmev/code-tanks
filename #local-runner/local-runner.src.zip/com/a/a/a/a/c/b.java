package com.a.a.a.a.c;

import com.a.a.a.a.a.m;
import com.a.a.a.a.a.n;
import com.a.a.a.a.a.o;

public abstract interface b
{
  public abstract void a(o paramo, n paramn, m paramm);

  public abstract com.a.a.a.a.a.b a(int paramInt1, int paramInt2);
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.c.b
 * JD-Core Version:    0.6.2
 */