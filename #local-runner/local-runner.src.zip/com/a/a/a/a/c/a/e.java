package com.a.a.a.a.c.a;

import com.a.a.a.a.a.b;
import com.a.a.a.a.a.m;
import com.a.a.a.a.a.n;
import com.a.a.a.a.a.o;
import java.io.Closeable;

public abstract interface e extends Closeable
{
  public abstract m[] a(o[] paramArrayOfo, n paramn);

  public abstract b[] b();

  public abstract void close();
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.c.a.e
 * JD-Core Version:    0.6.2
 */