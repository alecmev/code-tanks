package com.a.a.a.a.c.a;

import com.a.a.a.a.a.b;
import com.a.a.a.a.a.m;
import com.a.a.a.a.a.n;
import com.a.a.a.a.a.o;

public class f
  implements e
{
  private final int a;

  public f(int paramInt)
  {
    this.a = paramInt;
  }

  public m[] a(o[] paramArrayOfo, n paramn)
  {
    return new m[this.a];
  }

  public b[] b()
  {
    return new b[this.a];
  }

  public void close()
  {
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.c.a.f
 * JD-Core Version:    0.6.2
 */