package com.a.a.a.a.d;

import com.a.a.a.a.a.i;
import java.util.Comparator;

class c
  implements Comparator
{
  c(a parama)
  {
  }

  public int a(i parami1, i parami2)
  {
    return Integer.valueOf(parami2.b()).compareTo(Integer.valueOf(parami1.b()));
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.d.c
 * JD-Core Version:    0.6.2
 */