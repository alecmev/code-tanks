package com.a.a.a.a.d;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

class e extends WindowAdapter
{
  e(a parama)
  {
  }

  public void windowClosing(WindowEvent paramWindowEvent)
  {
    System.exit(0);
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.d.e
 * JD-Core Version:    0.6.2
 */