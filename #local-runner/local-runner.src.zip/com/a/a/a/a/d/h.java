package com.a.a.a.a.d;

import com.a.a.a.a.a.g;
import java.io.Closeable;
import java.io.IOException;

public abstract interface h extends Closeable
{
  public abstract void a(g paramg)
    throws IOException;
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.d.h
 * JD-Core Version:    0.6.2
 */