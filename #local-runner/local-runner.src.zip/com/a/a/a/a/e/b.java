package com.a.a.a.a.e;

public final class b
{
  public static final com.a.a.a.a.a.b a = com.a.a.a.a.a.b.b;

  private b()
  {
    throw new UnsupportedOperationException();
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.e.b
 * JD-Core Version:    0.6.2
 */