package com.a.a.a.a.a;

public enum e
{
  a, b;
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.a.e
 * JD-Core Version:    0.6.2
 */