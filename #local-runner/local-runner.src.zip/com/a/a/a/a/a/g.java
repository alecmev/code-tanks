package com.a.a.a.a.a;

import java.util.Arrays;

public final class g extends n
{
  private final j[] a;

  public g(n paramn, j[] paramArrayOfj)
  {
    super(paramn.b(), paramn.c(), paramn.d(), paramn.e(), paramn.f(), paramn.g(), paramn.h(), paramn.i(), paramn.j());
    this.a = ((j[])Arrays.copyOf(paramArrayOfj, paramArrayOfj.length));
  }

  public j[] a()
  {
    return (j[])Arrays.copyOf(this.a, this.a.length);
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.a.g
 * JD-Core Version:    0.6.2
 */