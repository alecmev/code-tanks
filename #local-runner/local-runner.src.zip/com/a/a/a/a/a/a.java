package com.a.a.a.a.a;

public final class a extends l
{
  public a(long paramLong, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    super(paramLong, paramDouble1, paramDouble2, paramDouble3, paramDouble4, 0.0D, 0.0D, 0.0D, 0.0D);
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.a.a
 * JD-Core Version:    0.6.2
 */