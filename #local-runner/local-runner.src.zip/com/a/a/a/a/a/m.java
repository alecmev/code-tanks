package com.a.a.a.a.a;

public final class m
{
  private double a;
  private double b;
  private double c;
  private d d;

  public double a()
  {
    return this.a;
  }

  public void a(double paramDouble)
  {
    this.a = paramDouble;
  }

  public double b()
  {
    return this.b;
  }

  public void b(double paramDouble)
  {
    this.b = paramDouble;
  }

  public double c()
  {
    return this.c;
  }

  public void c(double paramDouble)
  {
    this.c = paramDouble;
  }

  public d d()
  {
    return this.d;
  }

  public void a(d paramd)
  {
    this.d = paramd;
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.a.m
 * JD-Core Version:    0.6.2
 */