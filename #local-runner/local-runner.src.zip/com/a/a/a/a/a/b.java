package com.a.a.a.a.a;

public enum b
{
  a, b, c;
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.a.b
 * JD-Core Version:    0.6.2
 */