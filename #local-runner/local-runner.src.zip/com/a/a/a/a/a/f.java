package com.a.a.a.a.a;

import com.google.gson.annotations.Until;

public final class f extends l
{

  @Until(0.0D)
  private final String a;
  private final e b;

  public f(long paramLong, String paramString, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, e parame)
  {
    super(paramLong, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, paramDouble7, paramDouble8);
    this.a = paramString;
    this.b = parame;
  }

  public String a()
  {
    return this.a;
  }

  public e b()
  {
    return this.b;
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.a.f
 * JD-Core Version:    0.6.2
 */