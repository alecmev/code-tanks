package com.a.a.a.a.a;

public final class k extends l
{
  private final p a;

  public k(long paramLong, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, p paramp)
  {
    super(paramLong, paramDouble1, paramDouble2, paramDouble3, paramDouble4, 0.0D, 0.0D, 0.0D, 0.0D);
    this.a = paramp;
  }

  public p a()
  {
    return this.a;
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.a.k
 * JD-Core Version:    0.6.2
 */