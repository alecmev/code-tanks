package com.a.a.a.a.b.c.a;

public abstract class a extends com.a.a.d
{
  protected a(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    super(new com.a.b.b.d(paramDouble1, paramDouble2, paramDouble3, paramDouble4));
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.b.c.a.a
 * JD-Core Version:    0.6.2
 */