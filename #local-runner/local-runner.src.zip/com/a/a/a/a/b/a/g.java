package com.a.a.a.a.b.a;

public class g extends a
{
  public g(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt)
  {
    super(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramInt, 2.0D, new j());
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.b.a.g
 * JD-Core Version:    0.6.2
 */