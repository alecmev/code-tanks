package com.a.a.a.a.b.d;

import com.a.a.c;
import javax.vecmath.Vector2d;

public class g
  implements com.a.a.a
{
  public void a(c paramc)
  {
    com.a.a.a.a.b.c.c.a locala = (com.a.a.a.a.b.c.c.a)paramc.c();
    paramc.a().b(locala);
    paramc.a().a(new com.a.a.a.a.b.e.a(com.a.a.a.a.b.b.a.a(locala), paramc.d().x, paramc.d().y));
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.b.d.g
 * JD-Core Version:    0.6.2
 */