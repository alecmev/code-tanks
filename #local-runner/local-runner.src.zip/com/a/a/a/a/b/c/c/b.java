package com.a.a.a.a.b.c.c;

import com.a.a.a.a.b.c.d.d;
import com.a.b.b.c;

public class b extends a
{
  public b(int paramInt, d paramd)
  {
    super(paramInt, paramd, new c(22.5D, 7.5D), 0.5D, 800.0D, 0.0D, 250, 35, 1.570796326794897D, 0.0D);
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.b.c.c.b
 * JD-Core Version:    0.6.2
 */