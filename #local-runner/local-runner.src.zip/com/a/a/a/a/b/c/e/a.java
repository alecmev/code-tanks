package com.a.a.a.a.b.c.e;

import com.a.b.b.c;

public class a extends b
{
  public a(double paramDouble1, double paramDouble2)
  {
    super(new c(150.0D, 150.0D), paramDouble1, paramDouble2);
    d().g(0.5D);
    d().a(true);
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.b.c.e.a
 * JD-Core Version:    0.6.2
 */