package com.a.a.a.a.b.d;

import com.a.a.a.a.b.c.d.d;
import com.a.a.g;
import com.a.b.b;
import javax.vecmath.Vector2d;

public class e
  implements com.a.a.a
{
  public void a(com.a.a.c paramc)
  {
    d locald = (d)paramc.b();
    if (locald.d().f().length() > 100.0D)
      paramc.a().a(new com.a.a.a.a.b.e.a(com.a.a.a.a.a.c.k, paramc.d().x, paramc.d().y));
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.b.d.e
 * JD-Core Version:    0.6.2
 */