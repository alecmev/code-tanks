package com.a.a.a.a.b.c.d;

import com.a.a.a.a.b.h;
import com.a.b.b.c;

public class a extends d
{
  public a(h paramh, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3)
  {
    super(paramh, paramInt, paramDouble1, paramDouble2, paramDouble3, new c(112.5D, 67.5D), 15.0D, 0.02617993877991494D, 0.2617993877991494D, 97.5D, 5000.0D, 1750.0D, 100, 100, 250, 250, 250, 125, 100, 135);
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.b.c.d.a
 * JD-Core Version:    0.6.2
 */