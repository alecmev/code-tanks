package com.a.a.a.a.b.c.b;

import com.a.a.d;
import javax.vecmath.Vector2d;

public abstract class a extends d
{
  private int a;

  protected a(com.a.b.b.b paramb, Vector2d paramVector2d)
  {
    super(paramb);
    d().a(paramVector2d.x);
    d().b(paramVector2d.y);
    d().i(1.0D);
    this.a = 1000;
    d().e(0.005D);
    d().f(5.0D);
    d().g(0.5D);
    d().h(0.1D);
  }

  public int a()
  {
    return this.a;
  }

  public void a(int paramInt)
  {
    this.a = paramInt;
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.b.c.b.a
 * JD-Core Version:    0.6.2
 */