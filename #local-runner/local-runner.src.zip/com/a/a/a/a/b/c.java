package com.a.a.a.a.b;

import com.a.b.b;
import java.util.Map;
import javax.vecmath.Vector2d;

class c
  implements com.a.b.a
{
  c(a parama, Class paramClass1, Class paramClass2, com.a.a.a parama1)
  {
  }

  public void a(com.a.b.d paramd)
  {
    com.a.a.d locald1 = paramd.a() == null ? null : (com.a.a.d)a.a(this.d).get(paramd.a().a());
    com.a.a.d locald2 = paramd.b() == null ? null : (com.a.a.d)a.a(this.d).get(paramd.b().a());
    if ((this.a.isInstance(locald1)) && (this.b.isInstance(locald2)))
      this.c.a(new com.a.a.c(this.d, locald1, locald2, paramd.c(), paramd.d()));
    else if ((this.a.isInstance(locald2)) && (this.b.isInstance(locald1)))
      this.c.a(new com.a.a.c(this.d, locald2, locald1, paramd.c(), new Vector2d(-paramd.d().x, -paramd.d().y)));
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.b.c
 * JD-Core Version:    0.6.2
 */