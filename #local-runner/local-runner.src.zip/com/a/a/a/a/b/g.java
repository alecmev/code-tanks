package com.a.a.a.a.b;

import com.a.a.a.a.c.a.e;
import java.util.concurrent.Callable;

class g
  implements Callable
{
  g(b paramb, h paramh)
  {
  }

  public com.a.a.a.a.a.b[] a()
    throws Exception
  {
    return this.a.c().b();
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.b.g
 * JD-Core Version:    0.6.2
 */