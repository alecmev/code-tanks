package com.a.a.a.a.b;

import java.util.Comparator;

class d
  implements Comparator
{
  d(b paramb)
  {
  }

  public int a(h paramh1, h paramh2)
  {
    return Integer.valueOf(paramh2.f()).compareTo(Integer.valueOf(paramh1.f()));
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.b.d
 * JD-Core Version:    0.6.2
 */