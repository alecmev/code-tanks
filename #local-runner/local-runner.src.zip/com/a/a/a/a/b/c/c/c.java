package com.a.a.a.a.b.c.c;

import com.a.a.a.a.b.c.d.d;

public class c extends a
{
  public c(int paramInt, d paramd)
  {
    super(paramInt, paramd, new com.a.b.b.c(22.5D, 7.5D), 1.0D, 1000.0D, 0.215D, 0, 20, 1.047197551196598D, 0.1396263401595464D);
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.b.c.c.c
 * JD-Core Version:    0.6.2
 */