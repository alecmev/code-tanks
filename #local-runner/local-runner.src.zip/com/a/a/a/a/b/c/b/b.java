package com.a.a.a.a.b.c.b;

import com.a.b.b.c;
import javax.vecmath.Vector2d;

public class b extends a
{
  private final int a = 50;

  public b(Vector2d paramVector2d)
  {
    super(new c(30.0D, 30.0D), paramVector2d);
  }

  public int b()
  {
    return this.a;
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.b.c.b.b
 * JD-Core Version:    0.6.2
 */