package com.a.a.a.a.b;

import com.a.a.a.a.a.m;
import com.a.a.a.a.a.n;
import com.a.a.a.a.a.o;
import java.util.concurrent.Callable;

class e
  implements Callable
{
  e(b paramb, h paramh, o[] paramArrayOfo, n paramn)
  {
  }

  public m[] a()
    throws Exception
  {
    return this.a.c().a(this.b, this.c);
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.b.e
 * JD-Core Version:    0.6.2
 */