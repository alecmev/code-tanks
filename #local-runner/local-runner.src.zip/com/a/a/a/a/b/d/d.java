package com.a.a.a.a.b.d;

import com.a.a.g;
import javax.vecmath.Vector2d;

public class d
  implements com.a.a.a
{
  public void a(com.a.a.c paramc)
  {
    paramc.a().b(paramc.b());
    paramc.a().b(paramc.c());
    paramc.a().a(new com.a.a.a.a.b.e.a(com.a.a.a.a.a.c.m, paramc.d().x, paramc.d().y));
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.b.d.d
 * JD-Core Version:    0.6.2
 */