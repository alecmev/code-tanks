package com.a.a.a.a.b.c.e;

import com.a.a.d;

public abstract class b extends d
{
  protected b(com.a.b.b.b paramb, double paramDouble1, double paramDouble2)
  {
    super(paramb);
    d().a(paramDouble1);
    d().b(paramDouble2);
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.b.c.e.b
 * JD-Core Version:    0.6.2
 */