package com.a.a.a.a.b.d;

import com.a.a.a.a.b.b.f;
import com.a.a.a.a.b.c.d.d;
import com.a.a.g;
import javax.vecmath.Vector2d;

public class k
  implements com.a.a.a
{
  public void a(com.a.a.c paramc)
  {
    d locald = (d)paramc.b();
    com.a.a.a.a.b.c.b.b localb = (com.a.a.a.a.b.c.b.b)paramc.c();
    boolean bool = f.a(locald);
    f.b(locald, localb.b());
    paramc.a().b(localb);
    paramc.a().a(new com.a.a.a.a.b.e.a(com.a.a.a.a.a.c.p, paramc.d().x, paramc.d().y));
    if ((bool) && (!f.a(locald)))
      paramc.a().a(new com.a.a.a.a.b.e.a(com.a.a.a.a.a.c.s, locald.d().c(), locald.d().d()));
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.b.d.k
 * JD-Core Version:    0.6.2
 */