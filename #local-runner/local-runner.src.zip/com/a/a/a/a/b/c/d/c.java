package com.a.a.a.a.b.c.d;

import com.a.a.a.a.b.h;

public class c extends d
{
  public c(h paramh, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3)
  {
    super(paramh, paramInt, paramDouble1, paramDouble2, paramDouble3, new com.a.b.b.c(105.0D, 75.0D), 20.0D, 0.008726646259971648D, 6.283185307179586D, 82.5D, 7500.0D, 3750.0D, 100, 100, 250, 250, 200, 175, 100, 150);
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.b.c.d.c
 * JD-Core Version:    0.6.2
 */