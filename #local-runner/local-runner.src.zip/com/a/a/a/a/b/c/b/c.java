package com.a.a.a.a.b.c.b;

import javax.vecmath.Vector2d;

public class c extends a
{
  private final int a = 3;

  public c(Vector2d paramVector2d)
  {
    super(new com.a.b.b.c(30.0D, 30.0D), paramVector2d);
  }

  public int b()
  {
    return this.a;
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.b.c.b.c
 * JD-Core Version:    0.6.2
 */