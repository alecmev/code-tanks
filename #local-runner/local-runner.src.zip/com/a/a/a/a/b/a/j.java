package com.a.a.a.a.b.a;

import com.a.a.a.a.b.c.b.c;
import javax.vecmath.Vector2d;

class j
  implements a.a
{
  public c a()
  {
    return new c(new Vector2d(0.0D, 0.0D));
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.b.a.j
 * JD-Core Version:    0.6.2
 */