package com.a.a.a.a.b.a;

import com.a.a.a.a.b.c.b.b;
import javax.vecmath.Vector2d;

class i
  implements a.a
{
  public b a()
  {
    return new b(new Vector2d(0.0D, 0.0D));
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.b.a.i
 * JD-Core Version:    0.6.2
 */