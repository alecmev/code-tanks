package com.a.a.a.a.b.d;

import com.a.a.a.a.b.c.d.d;
import com.a.a.g;
import javax.vecmath.Vector2d;

public class a
  implements com.a.a.a
{
  public void a(com.a.a.c paramc)
  {
    d locald = (d)paramc.b();
    com.a.a.a.a.b.c.b.c localc = (com.a.a.a.a.b.c.b.c)paramc.c();
    locald.c(locald.s() + localc.b());
    paramc.a().b(localc);
    paramc.a().a(new com.a.a.a.a.b.e.a(com.a.a.a.a.a.c.q, paramc.d().x, paramc.d().y));
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.b.d.a
 * JD-Core Version:    0.6.2
 */