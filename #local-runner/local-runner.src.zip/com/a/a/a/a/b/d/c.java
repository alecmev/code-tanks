package com.a.a.a.a.b.d;

import com.a.a.a;
import com.a.a.g;

public class c
  implements a
{
  public void a(com.a.a.c paramc)
  {
    paramc.a().b(paramc.c());
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.b.d.c
 * JD-Core Version:    0.6.2
 */