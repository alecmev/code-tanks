package com.a.a.a.a.b.d;

import com.a.a.a.a.b.b.f;
import com.a.a.g;
import com.a.b.b;
import javax.vecmath.Vector2d;

public class h
  implements com.a.a.a
{
  public void a(com.a.a.c paramc)
  {
    com.a.a.a.a.b.c.d.d locald = (com.a.a.a.a.b.c.d.d)paramc.b();
    com.a.a.a.a.b.c.b.d locald1 = (com.a.a.a.a.b.c.b.d)paramc.c();
    boolean bool = f.a(locald);
    f.a(locald, locald1.b());
    paramc.a().b(locald1);
    paramc.a().a(new com.a.a.a.a.b.e.a(com.a.a.a.a.a.c.o, paramc.d().x, paramc.d().y));
    if ((bool) && (!f.a(locald)))
      paramc.a().a(new com.a.a.a.a.b.e.a(com.a.a.a.a.a.c.r, locald.d().c(), locald.d().d()));
  }
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.a.a.a.b.d.h
 * JD-Core Version:    0.6.2
 */