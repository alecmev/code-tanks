package com.a.b;

public abstract interface c
{
  public abstract b a(b paramb);

  public abstract void b(b paramb);

  public abstract b a(long paramLong);

  public abstract b b(long paramLong);

  public abstract void a();

  public abstract void a(a parama);

  public abstract int b();
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.b.c
 * JD-Core Version:    0.6.2
 */