package com.a.b;

public abstract interface a
{
  public abstract void a(d paramd);
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.b.a
 * JD-Core Version:    0.6.2
 */