package com.a.b.b;

public abstract class b
{
  public abstract b b();

  public abstract boolean a(b paramb, double paramDouble);
}

/* Location:           D:\stuff\work\random\CodeTanks\#local-runner\local-runner\
 * Qualified Name:     com.a.b.b.b
 * JD-Core Version:    0.6.2
 */